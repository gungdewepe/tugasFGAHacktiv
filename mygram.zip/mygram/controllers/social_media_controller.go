package controllers

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

type SocialMedia struct {
	ID   string `json:"id"`
	Name string `json:"name"`
	URL  string `json:"url"`
}

func getAllSocialMediaFromDatabase() []*SocialMedia {
	return []*SocialMedia{}
}

func getSocialMediaByIDFromDatabase(id string) *SocialMedia {
	return &SocialMedia{ID: id, Name: "Dummy Social Media", URL: "https://dummy-social-media.com"}
}

func createSocialMediaInDatabase(newSocialMedia *SocialMedia) {
	fmt.Printf("Created new social media: %+v\n", newSocialMedia)
}

func updateSocialMediaInDatabase(id string, updatedSocialMedia *SocialMedia) {
	fmt.Printf("Updated social media with ID %s: %+v\n", id, updatedSocialMedia)
}

func deleteSocialMediaFromDatabase(id string) {
	fmt.Printf("Deleted social media with ID %s\n", id)
}

func GetAllSocialMedia(c *gin.Context) {
	socialMedia := getAllSocialMediaFromDatabase()
	c.JSON(http.StatusOK, socialMedia)
}

func GetSocialMediaByID(c *gin.Context) {
	socialMedia := getSocialMediaByIDFromDatabase(c.Param("id"))
	c.JSON(http.StatusOK, socialMedia)
}

func CreateSocialMedia(c *gin.Context) {
	var newSocialMedia SocialMedia
	c.BindJSON(&newSocialMedia)
	createSocialMediaInDatabase(&newSocialMedia)
	c.JSON(http.StatusCreated, newSocialMedia)
}

func UpdateSocialMedia(c *gin.Context) {
	var updatedSocialMedia SocialMedia
	c.BindJSON(&updatedSocialMedia)
	updateSocialMediaInDatabase(c.Param("id"), &updatedSocialMedia)
	c.JSON(http.StatusOK, updatedSocialMedia)
}

func DeleteSocialMedia(c *gin.Context) {
	deleteSocialMediaFromDatabase(c.Param("id"))
	c.JSON(http.StatusOK, gin.H{"message": "Social media deleted successfully"})
}
