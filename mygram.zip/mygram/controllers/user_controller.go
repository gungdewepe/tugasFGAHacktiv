package controllers

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

type User struct {
	ID       string `json:"id"`
	Username string `json:"username"`
	Password string `json:"password"`
}

type LoginCredentials struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

func createUserInDatabase(newUser *User) {
	fmt.Printf("Created new user: %+v\n", newUser)
}

func authenticateUser(username, password string) (*User, error) {
	return &User{ID: "1", Username: username, Password: password}, nil
}

func updateUserInDatabase(userID string, updatedUser *User) {
	fmt.Printf("Updated user with ID %s: %+v\n", userID, updatedUser)
}

func deleteUserFromDatabase(userID string) {
	fmt.Printf("Deleted user with ID %s\n", userID)
}

func RegisterUser(c *gin.Context) {
	var newUser User
	c.BindJSON(&newUser)
	createUserInDatabase(&newUser)
	c.JSON(http.StatusCreated, newUser)
}

func LoginUser(c *gin.Context) {
	var loginUser LoginCredentials
	c.BindJSON(&loginUser)
	_, err := authenticateUser(loginUser.Username, loginUser.Password)
	if err != nil {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid credentials"})
		return
	}
	token := "dummy_token"
	c.JSON(http.StatusOK, gin.H{"token": token})
}

func UpdateUser(c *gin.Context) {
	var updatedUser User
	c.BindJSON(&updatedUser)
	updateUserInDatabase(c.Param("id"), &updatedUser)
	c.JSON(http.StatusOK, updatedUser)
}

func DeleteUser(c *gin.Context) {
	deleteUserFromDatabase(c.Param("id"))
	c.JSON(http.StatusOK, gin.H{"message": "User deleted successfully"})
}
