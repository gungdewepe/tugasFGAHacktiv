package controllers

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

type Photo struct {
	ID       string `json:"id"`
	Title    string `json:"title"`
	Caption  string `json:"caption"`
	PhotoURL string `json:"photo_url"`
}

func getAllPhotosFromDatabase() []*Photo {
	return []*Photo{}
}

func getPhotoByIDFromDatabase(id string) *Photo {
	return &Photo{ID: id, Title: "Dummy Title", Caption: "Dummy Caption", PhotoURL: "https://dummy-photo.com"}
}

func createPhotoInDatabase(newPhoto *Photo) {
	fmt.Printf("Created new photo: %+v\n", newPhoto)
}

func updatePhotoInDatabase(id string, updatedPhoto *Photo) {
	fmt.Printf("Updated photo with ID %s: %+v\n", id, updatedPhoto)
}

func deletePhotoFromDatabase(id string) {
	fmt.Printf("Deleted photo with ID %s\n", id)
}

func GetAllPhotos(c *gin.Context) {
	photos := getAllPhotosFromDatabase()
	c.JSON(http.StatusOK, photos)
}

func GetPhotoByID(c *gin.Context) {
	photo := getPhotoByIDFromDatabase(c.Param("id"))
	c.JSON(http.StatusOK, photo)
}

func CreatePhoto(c *gin.Context) {
	var newPhoto Photo
	c.BindJSON(&newPhoto)
	createPhotoInDatabase(&newPhoto)
	c.JSON(http.StatusCreated, newPhoto)
}

func UpdatePhoto(c *gin.Context) {
	var updatedPhoto Photo
	c.BindJSON(&updatedPhoto)
	updatePhotoInDatabase(c.Param("id"), &updatedPhoto)
	c.JSON(http.StatusOK, updatedPhoto)
}

func DeletePhoto(c *gin.Context) {
	deletePhotoFromDatabase(c.Param("id"))
	c.JSON(http.StatusOK, gin.H{"message": "Photo deleted successfully"})
}
