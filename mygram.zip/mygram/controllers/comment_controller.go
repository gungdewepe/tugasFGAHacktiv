package controllers

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

// Comment
type Comment struct {
	ID      string `json:"id"`
	UserID  string `json:"user_id"`
	PhotoID string `json:"photo_id"`
	Message string `json:"message"`
}

func getAllCommentsFromDatabase() []*Comment {
	return []*Comment{}
}

func getCommentByIDFromDatabase(id string) *Comment {
	return &Comment{ID: id, UserID: "user_id", PhotoID: "photo_id", Message: "Dummy Message"}
}

func createCommentInDatabase(newComment *Comment) {
	fmt.Println("Creating new comment in database:", newComment)
}

func updateCommentInDatabase(id string, updatedComment *Comment) {
	fmt.Println("Updating comment in database with ID:", id)
	fmt.Println("Updated comment:", updatedComment)
}

func deleteCommentFromDatabase(id string) {
	fmt.Println("Deleting comment from database with ID:", id)
}

func GetAllComments(c *gin.Context) {
	comments := getAllCommentsFromDatabase()
	c.JSON(http.StatusOK, comments)
}

func GetCommentByID(c *gin.Context) {
	comment := getCommentByIDFromDatabase(c.Param("id"))
	c.JSON(http.StatusOK, comment)
}

func CreateComment(c *gin.Context) {
	var newComment Comment
	c.BindJSON(&newComment)
	createCommentInDatabase(&newComment)
	c.JSON(http.StatusCreated, newComment)
}

func UpdateComment(c *gin.Context) {

	var updatedComment Comment
	c.BindJSON(&updatedComment)
	updateCommentInDatabase(c.Param("id"), &updatedComment)
	c.JSON(http.StatusOK, updatedComment)
}

func DeleteComment(c *gin.Context) {
	deleteCommentFromDatabase(c.Param("id"))
	c.JSON(http.StatusOK, gin.H{"message": "Comment deleted successfully"})
}
