package models

import (
	"time"
)

type Comment struct {
	ID        uint64    `gorm:"primary_key" json:"id"`
	UserID    uint64    `gorm:"not null" json:"user_id"`
	PhotoID   uint64    `gorm:"not null" json:"photo_id"`
	Message   string    `gorm:"not null" json:"message"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

func (c *Comment) TableName() string {
	return "comments"
}
