package models

import (
	"time"
)

type SocialMedia struct {
	ID             uint64    `gorm:"primary_key" json:"id"`
	Name           string    `gorm:"not null" json:"name"`
	SocialMediaURL string    `gorm:"not null" json:"social_media_url"`
	UserID         uint64    `gorm:"not null" json:"user_id"`
	CreatedAt      time.Time `json:"created_at"`
	UpdatedAt      time.Time `json:"updated_at"`
}

func (s *SocialMedia) TableName() string {
	return "social_media"
}
