package models

import (
	"time"
)

type User struct {
	ID              uint64    `gorm:"primary_key" json:"id"`
	Username        string    `gorm:"unique_index;not null" json:"username"`
	Email           string    `gorm:"unique_index;not null" json:"email"`
	Password        string    `gorm:"not null" json:"-"`
	Age             int       `gorm:"not null" json:"age"`
	ProfileImageURL string    `json:"profile_image_url"`
	CreatedAt       time.Time `json:"created_at"`
	UpdatedAt       time.Time `json:"updated_at"`
}

func (u *User) TableName() string {
	return "users"
}
