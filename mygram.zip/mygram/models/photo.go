package models

import (
	"time"
)

type Photo struct {
	ID        uint64    `gorm:"primary_key" json:"id"`
	Title     string    `gorm:"not null" json:"title"`
	Caption   string    `json:"caption"`
	PhotoURL  string    `gorm:"not null" json:"photo_url"`
	UserID    uint64    `gorm:"not null" json:"user_id"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

func (p *Photo) TableName() string {
	return "photos"
}
