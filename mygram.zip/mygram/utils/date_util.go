package utils

import "time"

func FormatDate(date time.Time, format string) string {
	return date.Format(format)
}

func GetCurrentTimestamp() int64 {
	return time.Now().Unix()
}
