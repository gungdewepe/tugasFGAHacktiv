package utils

import (
	"io/ioutil"
	"os"
)

func ReadFile(filename string) ([]byte, error) {
	data, err := ioutil.ReadFile(filename)
	if err != nil {
		return nil, err
	}
	return data, nil
}

func WriteFile(filename string, data []byte) error {
	err := ioutil.WriteFile(filename, data, os.ModePerm)
	if err != nil {
		return err
	}
	return nil
}
