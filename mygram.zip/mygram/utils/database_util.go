package utils

import (
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/mysql" // Import MySQL dialect
)

var db *gorm.DB

func InitializeDB() (*gorm.DB, error) {
	var err error
	db, err = gorm.Open("mysql", "user:password@tcp(localhost:3306)/database_name?charset=utf8&parseTime=True&loc=Local")
	if err != nil {
		return nil, err
	}
	return db, nil
}

func GetDB() *gorm.DB {
	return db
}
