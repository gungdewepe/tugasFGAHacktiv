package main

import (
	"github.com/gin-gonic/gin"
)

func main() {
	routers := gin.Default()

	router := gin.Default()
	routers.InitializeRoutes(router)
	router.Run(":8080")
}
