package main

import (
	middleware "mygram/middlewares"

	controllers "mygram/controllers"

	"github.com/gin-gonic/gin"
)

func setupRouter() *gin.Engine {
	router := gin.Default()

	router.Use(middleware.AuthMiddleware())

	userController := &controllers.UserController{}
	photoController := &controllers.PhotoController{}
	commentController := &controllers.CommentController{}
	socialMediaController := &controllers.SocialMediaController{}

	userRoutes := router.Group("/users")
	{
		userRoutes.POST("/register", userController.Register)
		userRoutes.POST("/login", userController.Login)
		userRoutes.PUT("/", userController.Update)
		userRoutes.DELETE("/", userController.Delete)
	}

	photoRoutes := router.Group("/photos")
	{
		photoRoutes.GET("/", photoController.GetAll)
		photoRoutes.GET("/:id", photoController.GetOne)
		photoRoutes.POST("/", photoController.Create)
		photoRoutes.PUT("/:id", photoController.Update)
		photoRoutes.DELETE("/:id", photoController.Delete)
	}

	commentRoutes := router.Group("/comments")
	{
		commentRoutes.GET("/", commentController.GetAll)
		commentRoutes.GET("/:id", commentController.GetOne)
		commentRoutes.POST("/", commentController.Create)
		commentRoutes.PUT("/:id", commentController.Update)
		commentRoutes.DELETE("/:id", commentController.Delete)
	}

	socialMediaRoutes := router.Group("/socialmedias")
	{
		socialMediaRoutes.GET("/", socialMediaController.GetAll)
		socialMediaRoutes.GET("/:id", socialMediaController.GetOne)
		socialMediaRoutes.POST("/", socialMediaController.Create)
		socialMediaRoutes.PUT("/:id", socialMediaController.Update)
		socialMediaRoutes.DELETE("/:id", socialMediaController.Delete)
	}

	return router
}
